/* Copyright 2008 (C) Nicira, Inc.
 *
 * This file is part of NOX.
 *
 * NOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * NOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with NOX.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "hoolock.hh"
#include "assert.hh"
#include "packets.h"
#include "netinet++/ethernet.hh"
#include "messenger/messenger-event.hh"
#include <unistd.h>
#include <sstream>

#define DP_FROM_AP(loc) ((loc) & 0xffffffffffffULL)
#define FLOW_TIMEOUT    5
#define BROADCAST_TIMEOUT   60
#define SLEEP_TIME	100 * 1000
#define HDBG cout << "HOOLOCK:"

using namespace std;
using namespace vigil;
using namespace vigil::container;

namespace vigil {
namespace applications {

/* Define functions and such */

Hoolock::Hoolock(const Context* c, const xercesc::DOMNode* x):
	Component(c), routing(NULL), empty(new Routing_module::Route())
{}

void
Hoolock::getInstance(const container::Context * ctxt,
                       Hoolock*& s)
{
    s = dynamic_cast<Hoolock*>
        (ctxt->get_by_interface(container::Interface_description
                                (typeid(Hoolock).name())));
}

void
Hoolock::configure(const Configuration* conf) 
{
	// Parse the configuration, register event handlers, and
	// resolve any dependencies.
#ifdef LOG4CXX_ENABLED
	LOG4CXX_DEBUG(lg, "Configure called");
	LOG4CXX_DEBUG(lg, boost::format("Formatting is %1% as %2%+%2%") 
			% "easy" % 1);
#else
	lg.dbg(" Configure called ");
#endif
	resolve(routing);
	register_handler<Flow_in_event>(boost::bind(&Hoolock::handle_flow_in, this, _1));
	register_handler<Hoolock_msg_event>(boost::bind(&Hoolock::handle_hoolock_msg, this, _1));
	register_handler<Flow_expired_event>(boost::bind(&Hoolock::handle_flow_expired, this, _1));
	
}

void 
Hoolock::install() 
{
	// Start the component. For example, if any threads require
	// starting, do it now.
#ifdef LOG4CXX_ENABLED
	LOG4CXX_DEBUG(lg, "Install called");
#else
	lg.dbg(" Install called ");
#endif
	
}

/* Private functions */

static struct ip_header *
pull_ip(Buffer& b)
{
    if (struct ip_header *ip = b.try_at<ip_header>(0)) {
        int ip_len = IP_IHL(ip->ip_ihl_ver) * 4;
        if (ip_len >= sizeof *ip) {
            return reinterpret_cast<struct ip_header*>(b.try_pull(ip_len));
        }
    }
    return 0;
}


static struct tcp_header *
pull_tcp(Buffer& b)
{
    if (struct tcp_header *tcp = b.try_at<tcp_header>(0)) {
        int tcp_len = TCP_OFFSET(tcp->tcp_ctl) * 4;
        if (tcp_len >= sizeof *tcp) {
            return reinterpret_cast<struct tcp_header*>(b.try_pull(tcp_len));
        }
    }
    return 0;
}


Disposition 
Hoolock::handle_flow_in(const Event& e)
{
	const Flow_in_event& fi = assert_cast<const Flow_in_event&>(e);
	
	/* Ignore broadcast */
	if(fi.flow.dl_dst.string() == "ff:ff:ff:ff:ff:ff") {
		return CONTINUE;
	}
	/* Ignore non-IP messages */
	else if(fi.flow.nw_src == 0 || fi.flow.nw_dst == 0) {
		return CONTINUE;
	}
	uint32_t seq = -1;
        uint16_t ipid = -1;
	struct tcp_header* tcphdr = pull_tcp(*(fi.buf));
	struct ip_header* iphdr = pull_ip(*(fi.buf));
	if(tcphdr) {
		seq = tcphdr->tcp_seq;
	}
	if(iphdr)
		ipid = iphdr->ip_id;
	//HDBG << "----------- Got a flow-in: tcp-seq " << seq << " : ip-id " << ipid << " : time " << fi.received << " ----------\n" 
	HDBG << "----------- Got a flow-in: ----------\n" 
		<< fi.flow.to_string() << endl;

	/* Get old route
	 * route - has the straight route
	 * inport, outport - inport and the outport of the OF-path
	 */
	Routing_module::RoutePtr route;
	uint16_t inport, outport;
	if(!set_route(fi, route, inport, outport)) {
		return CONTINUE;
	}
	//HDBG << "Got a route: " << route_to_string(*route) << endl;

	ethernetaddr src_mac = fi.flow.dl_src;
	ethernetaddr dst_mac = fi.flow.dl_dst;
	route_db::iterator src_rit = db.find(src_mac.string());
	route_db::iterator dst_rit = db.find(dst_mac.string());

	/*
	 * Get source
	 * lookup db
	 * if src in transition
	 * 	get rev path, rev flow
	 * 	lookup db->src for matching flow and do flow switch
	 * add flow, path to db->dst
	 */
	if((src_rit != db.end()) && src_rit->second.in_transition) {
		HDBG << "Time to switch some flows!" << endl;
		/* Handover */
		vector<Flow>& fvec = src_rit->second.flows;
		vector<Routing_module::RoutePtr>& rvec = src_rit->second.routes;
		vector<bool>& svec = src_rit->second.switched;
		vector<uint16_t>& invec = src_rit->second.inports;
		vector<uint16_t>& outvec = src_rit->second.outports;
		Flow& rev_flow = get_rev_flow(fi.flow, outport);
		//HDBG << "----------- Reverse flow: ----------\n" 
		//	<< rev_flow.to_string() << endl;
		/* Find reverse route */
		Routing_module::RoutePtr new_route;
	       	reverse(route, new_route);
		//HDBG << "Reverse route: " << route_to_string(*new_route) << endl;


		for(int i = 0; i < fvec.size(); i++) {
			if(flow_route_cmp(fvec[i], rev_flow) && !svec[i]) {		//XXX:Assumption: if two flows compare with flow_route_cmp, they'll have the same old_route
				svec[i] = true;
				/* Found the matching reverse flow */
				Flow rev_action_flow = fvec[i];
				HDBG << "----------- Found matching flow: ----------\n" 
					<< rev_action_flow.to_string() << endl;
				Routing_module::RoutePtr& old_route = rvec[i];

				/* The new branch - root switch onwards */
				Routing_module::RoutePtr new_branch(new Routing_module::Route());
				Routing_module::RoutePtr old_branch(new Routing_module::Route());
				uint16_t new_branch_inport, new_branch_outport;
				uint16_t old_branch_inport = -1, old_branch_outport = -1;
				Routing_module::RoutePtr node_route(new Routing_module::Route());
				//node_route.reset(new Routing_module::Route());

				/* Find root switch 
				 * root_link->dst is the root switch
				 */
				list<Routing_module::Link>::reverse_iterator old_rpos, new_rpos;
				list<Routing_module::Link>::iterator root_link;
				bool breaker = false;
				bool reset_old_branch = false;
				for(old_rpos = old_route->path.rbegin(); old_rpos != old_route->path.rend() && !breaker; old_rpos++) {
					for(new_rpos = new_route->path.rbegin(); new_rpos != new_route->path.rend(); new_rpos++) {
						if(old_rpos->dst == new_rpos->dst && old_rpos->outport == new_rpos->outport 
								&& old_rpos->inport == new_rpos->inport) {
							// Found root switch!
							
							// Modify the old_route to the new_route
							list<Routing_module::Link>::iterator old_pos(old_rpos.base()), new_pos(new_rpos.base());
							root_link = old_pos;
							root_link--;
							if(old_pos != old_route->path.end()) {
								old_pos++;
								old_branch->path.insert(old_branch->path.end(), old_pos, old_route->path.end());
								old_pos--;
								old_branch->id.src = old_pos->dst;
								old_branch->id.dst = old_route->id.dst;
								old_branch_inport = old_pos->inport;
								old_branch_outport = outvec[i];
								reset_old_branch = true;
							}
							// Truncate the old route to remove the old branch
							old_route->path.erase(old_pos, old_route->path.end());
							// Populate the new branch
							new_branch->path.insert(new_branch->path.end(), new_pos, new_route->path.end());
							// Append new branch to the truncated old route
							old_route->path.splice(old_route->path.end(), new_branch->path);
							breaker = true; // Break out of the outer loop
							break;
						}
					}
				}

				if(breaker) { //Root switch is not id.src
					/* Add flow entry to the path root-sw onwards */
					new_branch->id.src = root_link->dst;
					new_branch->id.dst = new_route->id.dst;
					new_branch_inport = root_link->inport;
					new_branch_outport = inport;
					HDBG << "-------------------------------\n"
						<< "Switching route " << route_to_string(*old_route) << "\n"
						<< "to " << route_to_string(*new_route) << "\n"
						<< "Root switch : " << root_link->dst.string() << "\n"
						<< "New branch " << route_to_string(*new_branch) << "\n";

					setup_route(rev_action_flow, *new_branch, new_branch_inport, new_branch_outport, FLOW_TIMEOUT,
							Routing_module::ActionList(0), fi.dst_addr_groups.get(),
							fi.src_addr_groups.get());

					if(reset_old_branch) {
						//Reinforce the old path - to correct some bug in existing nox
						setup_route(rev_action_flow, *old_branch, old_branch_inport, old_branch_outport, FLOW_TIMEOUT,
								Routing_module::ActionList(0), fi.dst_addr_groups.get(),
								fi.src_addr_groups.get());
					}
				}
				else if(new_route->id.src == old_route->id.src) { //Root switch is id.src
					new_branch_inport = outport;
					new_branch_outport = inport;
					HDBG << "-------------------------------\n"
						<< "Switching route " << route_to_string(*old_route) << "\n"
						<< "to " << route_to_string(*new_route) << "\n"
						<< "Root switch : " << new_route->id.src.string() << "\n"
						<< "New branch " << route_to_string(*new_route) << "\n";
					setup_route(rev_action_flow, *new_route, new_branch_inport, new_branch_outport, FLOW_TIMEOUT,
							Routing_module::ActionList(0), fi.dst_addr_groups.get(),
							fi.src_addr_groups.get());
					if(old_route->path.size() > 0) {
						list<Routing_module::Link>::iterator old_branch_start = old_route->path.begin();
					        old_branch_start++;
						old_branch->path.insert(old_branch->path.end(), old_branch_start, old_route->path.end());
						old_branch->id.src = old_route->path.front().dst;
						old_branch->id.dst = old_route->id.dst;
						old_branch_inport = old_route->path.front().inport;
						old_branch_outport = outvec[i];
						setup_route(rev_action_flow, *old_branch, old_branch_inport, old_branch_outport, FLOW_TIMEOUT,
								Routing_module::ActionList(0), fi.dst_addr_groups.get(),
								fi.src_addr_groups.get());
					}
				}
				else {
					HDBG << "No common switch between the paths! Not switching" << endl;
				}
				
			}
		}
	}

	Flow f = fi.flow;
	if(!add_db(fi.flow.dl_dst.string(), route, inport, outport, f)) {
		cout << "Error! Couldn't add route to db - shouldn't happen" << endl;
	}

	return CONTINUE;
}

Disposition 
Hoolock::handle_hoolock_msg(const Event& e)
{
	const Hoolock_msg_event& hmsg = assert_cast<const Hoolock_msg_event&>(e);
	
	string client = hmsg.mac.string();
	route_db::iterator src_rit = db.find(client);
	if(src_rit == db.end()) {
		HDBG << "Receiving Hoolock_msg from unknown client " << client << " - creating a DB key" << endl;
		/*route_data rdata;
		rdata.routes.clear();
		rdata.flows.clear();
		rdata.in_transition = false;
		db[client] = rdata;*/
		db[client] = route_data();
		src_rit = db.find(client);
	}
	bool& in_trans = src_rit->second.in_transition;
	vector<bool>& svec = src_rit->second.switched;
	int reply_size = sizeof(struct Hoolock_msg) + 1;
	char *reply = new char[reply_size];
	reply[reply_size - 1] = ';';
	struct Hoolock_msg *hreply = (struct Hoolock_msg *)reply;
	Nonowning_buffer buf(reply, reply_size);
	switch(hmsg.cmd) {
		case MAKE_REQ:
			HDBG << "-------------------------------\n"
			<< "MAKE_REQ from client : " << client << " in transition\n";
			in_trans = true;
			//send MAKE_ACK;
			hreply->cmd = MAKE_ACK;
			hmsg.sock->write(buf, false);
			break;
		case BREAK_REQ:
			in_trans = false;
			HDBG << "-------------------------------\n"
			<< "BREAK_REQ from client : " << client << " out of transition\n";
			for(int i = 0; i < svec.size(); i++) {
				svec[i] = false;
			}
			usleep(SLEEP_TIME);
			//send BREAK_ACK
			hreply->cmd = BREAK_ACK;
			hmsg.sock->write(buf, false);
			break;
		default:
			cout << "Unexpected client message...ignoring" << endl;
	}

	return CONTINUE;
}

Disposition 
Hoolock::handle_flow_expired(const Event& e)
{
	const Flow_expired_event& fe = assert_cast<const Flow_expired_event&>(e);
	const ofp_match* ofpm = fe.get_flow();
	if(ofpm == NULL) {
		return CONTINUE;
	}
	Flow expired_flow(ofpm->in_port, ofpm->dl_vlan,
			ethernetaddr(ofpm->dl_src), ethernetaddr(ofpm->dl_dst), ofpm->dl_type,
			ofpm->nw_src, ofpm->nw_dst, ofpm->nw_proto,
			ofpm->tp_src, ofpm->tp_dst);
	route_db::iterator rit = db.find(expired_flow.dl_dst.string());
	if(rit == db.end()) {
		return CONTINUE;
	}

	vector<Flow>& fvec = rit->second.flows;
	vector<Routing_module::RoutePtr>& rvec = rit->second.routes;
	vector<bool>& svec = rit->second.switched;
	vector<uint16_t>& invec = rit->second.inports;
	vector<uint16_t>& outvec = rit->second.outports;
	for(int i = 0; i < rit->second.flows.size(); i++) {
		if(flow_app_cmp(fvec[i], expired_flow)) {
			//Check if the switch is on route
			bool on_route = false;
			if(rvec[i]->id.src == fe.datapath_id)
				on_route = true;
			else {
				for(list<Routing_module::Link>::iterator link = rvec[i]->path.begin(); link != rvec[i]->path.end(); link++) {
					if(link->dst == fe.datapath_id) {
						on_route = true;
						break;
					}
				}
			}
			if(!on_route)
				continue;
			HDBG << "--------------------Flow expired - erasing:---------------\n"
				<< fvec[i].to_string() << endl;
			fvec.erase(fvec.begin()+i);
			rvec.erase(rvec.begin()+i);
			svec.erase(svec.begin()+i);
			invec.erase(invec.begin()+i);
			outvec.erase(outvec.begin()+i);
			i--;
		}
	}
	return CONTINUE;
}

bool 
Hoolock::add_db(string mac, Routing_module::RoutePtr rptr, uint16_t inport, uint16_t outport, Flow& flow)
{
	HDBG << "--------------- Add DB -------------\n"
		<< "Host : " << mac << "\n"
		<< "Route " << route_to_string(*rptr) << "\n"
		<< "Flow : " << flow.to_string() << "\n";

	route_db::iterator rit = db.find(mac);
	if(rit == db.end()) {
		db[mac] = route_data();
		rit = db.find(mac);
		route_data& rdata = rit->second;
		rdata.routes.push_back(rptr);
		rdata.inports.push_back(inport);
		rdata.outports.push_back(outport);
		rdata.flows.push_back(flow);
		rdata.switched.push_back(false);
		HDBG << "Note : Creating a new DB key\n";
	}
	else {
		vector<Flow>& fvec = rit->second.flows;
		vector<bool>& svec = rit->second.switched;
		vector<Routing_module::RoutePtr>& rvec = rit->second.routes;
		vector<uint16_t>& invec = rit->second.inports;
		vector<uint16_t>& outvec = rit->second.outports;
		for(int i = 0; i < fvec.size(); i++) {
			//if(fvec[i].hash_code() == flow.hash_code()) {
			//}
			if(flow_app_cmp(fvec[i], flow)) {
				fvec[i] = flow;
				rvec[i] = rptr;
				HDBG << "Note : Replacing a DB entry\n";
				return true;
			}
		}
		rvec.push_back(rptr);
		invec.push_back(inport);
		outvec.push_back(outport);
		fvec.push_back(flow);
		svec.push_back(false);
		HDBG << "Note : Adding a DB entry\n";
	}
	return true;
}

Flow&
Hoolock::get_rev_flow(const Flow& flow, uint16_t inport)
{
	Flow *rev = new Flow(inport, flow.dl_vlan, 
			flow.dl_dst, flow.dl_src, flow.dl_type,
			flow.nw_dst, flow.nw_src, flow.nw_proto,
			flow.tp_dst, flow.tp_src);
	return *rev;
}

bool
Hoolock::set_route(const Flow_in_event& fi,
                     Routing_module::RoutePtr& route,
                     uint16_t& inport, uint16_t& outport)
{
    if (fi.src_to_route == NULL) {
        empty->id.src = datapathid::from_host(DP_FROM_AP(fi.src->location));
        inport = (uint16_t)(fi.src->location >> 48);
    } else {
        empty->id.src = datapathid::from_host(DP_FROM_AP(fi.src_to_route->location));
        inport = (uint16_t)(fi.src_to_route->location >> 48);
    }

    const ConnList *dst;
    if (fi.dst_to_route.empty()) {
        dst = &fi.dst;
    } else {
        dst = &fi.dst_to_route;
    }

    if (!dst->empty() && dst->front()->location != 0) {
        bool checked = false;
        for (ConnList::const_iterator iter = dst->begin();
             iter != dst->end(); ++iter)
        {
            bool check = false;
            empty->id.dst = datapathid::from_host(DP_FROM_AP((*iter)->location));
            if (empty->id.src == empty->id.dst) {
                route = empty;
                check = true;
            } else {
                check = routing->get_route(empty->id, route);
            }

            if (check) {
                checked = true;
                outport = (uint16_t) ((*iter)->location >> 48);
                if (routing->check_route(*route, inport, outport)) {
                    return true;
                }
                VLOG_DBG(lg, "Invalid route between aps %"PRIx64":%"PRIu16" and %"PRIx64":%"PRIu16".",
                          empty->id.src.as_host(), inport, empty->id.dst.as_host(), outport);
            } else {
                VLOG_DBG(lg, "No route found between dps %"PRIx64" and %"PRIx64".",
                          empty->id.src.as_host(), empty->id.dst.as_host());
            }
        }

//   If failed on check_route(), don't route...correct?
        if (checked) {
            VLOG_WARN(lg, "Could not find valid route to any destination.");
            std::ostringstream os;
            os << fi.flow;
            VLOG_WARN(lg, "Dropping %s", os.str().c_str());
            return false;
        }
    }

    /*if (lg.is_dbg_enabled()) {
        std::ostringstream os;
        os << fi.flow;
        VLOG_DBG(lg, "Broadcasting %s", os.str().c_str());
    }

    if (fi.flow.dl_dst.is_broadcast()) {
        routing->setup_flow(fi.flow, fi.datapath_id, OFPP_FLOOD,
                            fi.buffer_id, *(fi.buf), BROADCAST_TIMEOUT,
                            fi.flow.dl_type == ethernet::IP && false,  // CHANGE
                                                                       // WHEN
                                                                       // NAT ENABLED
                            fi.src_addr_groups.get(), fi.dst_addr_groups.get());
    } else {
        routing->send_packet(fi.datapath_id, ntohs(fi.flow.in_port), OFPP_FLOOD,
                             fi.buffer_id, *(fi.buf),
                             fi.flow.dl_type == ethernet::IP && false, // CHANGE
                                                                       // WHEN
                                                                       // NAT ENABLED
                             fi.flow,
                             fi.src_addr_groups.get(), fi.dst_addr_groups.get());
    }*/

    return false;
}

bool 
Hoolock::setup_route(const Flow& flow, Routing_module::Route& route, uint16_t inport,
                     uint16_t outport, uint16_t flow_timeout,
                     const Routing_module::ActionList& actions,
                     const vector<uint32_t> *saddr_groups,
                     const vector<uint32_t> *daddr_groups)
{
	/*routing->setup_route(flow, route, inport, outport, flow_timeout,
	  actions, saddr_groups,daddr_groups);*/

	//Add flow entries in the reverse route direction
	Routing_module::RoutePtr node_route(new Routing_module::Route());
	uint16_t node_inport, node_outport = outport;
	list<Routing_module::Link>::reverse_iterator link_it;
	for(link_it = route.path.rbegin(); link_it != route.path.rend(); link_it++) {
		node_route->id.src = node_route->id.dst = link_it->dst;
		node_inport = link_it->inport;
		routing->setup_route(flow, *node_route, node_inport, node_outport, flow_timeout,
				Routing_module::ActionList(0), saddr_groups, daddr_groups);
		node_outport = link_it->outport;
	}
	node_route->id.src = node_route->id.dst = route.id.src;
	node_inport = inport;
	routing->setup_route(flow, *node_route, node_inport, node_outport, flow_timeout,
			Routing_module::ActionList(0), saddr_groups, daddr_groups);
	return true;
}


//Routing_module::RoutePtr& 
void
Hoolock::reverse(Routing_module::RoutePtr& route, Routing_module::RoutePtr& rev)
{
	//Routing_module::RoutePtr rev(new Routing_module::Route());
	rev.reset(new Routing_module::Route());
	rev->id.src = route->id.dst;
	rev->id.dst = route->id.src;

	list<Routing_module::Link>::const_reverse_iterator ite = route->path.rbegin();
	Routing_module::Link tmp;
	while(true) {
		tmp.inport = ite->outport;
		tmp.outport = ite->inport;

		ite++;
		if(ite == route->path.rend()) {
			tmp.dst = rev->id.dst;
			rev->path.push_back(tmp);
			break;
		}
		else {
			tmp.dst = ite->dst;
			rev->path.push_back(tmp);
		}
	}
	//return rev;
}

bool
Hoolock::flow_route_cmp(const Flow& f1, const Flow& f2)
{
	return ((f1.dl_vlan == f2.dl_vlan)
			&& (f1.dl_src == f2.dl_src)
			&& (f1.dl_dst == f1.dl_dst)
			&& (f1.dl_type == f1.dl_type)
			&& (f1.nw_src == f1.nw_src)
			&& (f1.nw_dst == f1.nw_dst)
			&& (f1.nw_proto == f1.nw_proto)
	       );
}

bool
Hoolock::flow_app_cmp(const Flow& f1, const Flow& f2)
{
	return (flow_route_cmp(f1, f2)
			&& (f1.tp_src == f2.tp_src)
			&& (f1.tp_dst == f2.tp_dst)
	       );
}

string 
Hoolock::route_to_string(Routing_module::Route& route)
{
	stringstream ss;
	ss << route.id.src.string(); 
	for(list<Routing_module::Link>::iterator ite = route.path.begin(); ite != route.path.end(); ite++) {
		ss << ":";
		ss << ite->outport;
		ss << "->";
		ss << ite->inport;
		ss << ":";
		ss << ite->dst.string(); 
	}
	return ss.str();
}

/* Register component */

REGISTER_COMPONENT(container::Simple_component_factory<Hoolock>,
                   Hoolock);

} // applications
} // vigil
