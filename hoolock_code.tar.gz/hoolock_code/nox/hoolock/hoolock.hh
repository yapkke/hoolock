/* Copyright 2008 (C) Nicira, Inc.
 *
 * This file is part of NOX.
 *
 * NOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * NOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with NOX.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef HOOLOCK_HH
#define HOOLOCK_HH 1

#include <iostream>

#include "component.hh" 
#include "config.h" 
#include "routing/sprouting.hh"
#include "routing/routing.hh"
#include "messenger/messenger-event.hh"
#include "netinet++/ethernet.hh"
#include "flow-expired.hh"

#include <xercesc/dom/DOM.hpp> 

#ifdef LOG4CXX_ENABLED
#include <boost/format.hpp>
#include "log4cxx/logger.h"

#else
#include "vlog.hh"
#endif

using namespace std;
using namespace vigil;
using namespace vigil::container;
using namespace vigil::applications;

namespace vigil {
namespace applications {


#ifdef LOG4CXX_ENABLED
static log4cxx::LoggerPtr lg(log4cxx::Logger::getLogger
                             ("nox.apps.hoolock"));
#else
static Vlog_module lg("hoolock");
#endif

struct streq {
	bool operator()(string s1, string s2) const
	{
		return (s1 == s2);
	}
};

struct strhash {
	size_t operator()(const string& s) const
	{
		HASH_NAMESPACE::hash<const char*> h;
		return h(s.c_str());
	}
};

class route_data{
	public:
	//Constructor
	route_data()
	{
		routes = vector<Routing_module::RoutePtr>();
		flows = vector<Flow>();
		switched = vector<bool>();
		in_transition = false;
	}

	vector<Routing_module::RoutePtr> routes;
	vector<Flow> flows;
	vector<bool> switched;
	vector<uint16_t> inports;
	vector<uint16_t> outports;
	bool in_transition;
	private:
};

class Hoolock
    : public Component {
public:
    Hoolock(const Context*, const xercesc::DOMNode*);
    ~Hoolock() { }
    static void getInstance(const container::Context*, Hoolock*&);
    void configure(const Configuration*);
    void install();
    Disposition handle_flow_in(const Event&);
    Disposition handle_hoolock_msg(const Event&);
    Disposition handle_flow_expired(const Event&);

    typedef hash_map<string, route_data> route_db;

private:
    Routing_module *routing;
    Routing_module::RoutePtr empty;

    /* creates a new Flow object and returns it's reference */
    Flow& get_rev_flow(const Flow& flow, uint16_t inport);
    bool set_route(const Flow_in_event& fi,
		    Routing_module::RoutePtr& route,
		    uint16_t& inport, uint16_t& outport);
    bool setup_route(const Flow& flow, Routing_module::Route& route, uint16_t inport,
                     uint16_t outport, uint16_t flow_timeout,
                     const Routing_module::ActionList& actions,
                     const vector<uint32_t> *saddr_groups,
                     const vector<uint32_t> *daddr_groups);
    //Routing_module::RoutePtr& reverse(Routing_module::RoutePtr&);
    void reverse(Routing_module::RoutePtr&, Routing_module::RoutePtr&);

    /* Route database */
    route_db db;
    bool add_db(string mac, Routing_module::RoutePtr rptr, uint16_t inport, uint16_t outport, Flow& flow);

    /* Util functions */
    bool flow_route_cmp(const Flow& f1, const Flow& f2);
    bool flow_app_cmp(const Flow& f1, const Flow& f2);
    string route_to_string(Routing_module::Route&);

};

}
}

#endif // HOOLOCK_HH
