#include "messenger_proxy.hh"
#include "pyrt/pycontext.hh"
#include "swigpyrun.h"
#include "vlog.hh"

using namespace std;
using namespace vigil;
using namespace vigil::applications;

namespace {
  Vlog_module lg("messenger-proxy");
}

namespace vigil
{
  namespace applications
  {
    messenger_proxy::messenger_proxy(PyObject* ctxt)
    {
      PySwigObject* swigo = SWIG_Python_GetSwigThis(ctxt);
      if (!swigo || !swigo->ptr) {
        throw runtime_error("Unable to access Python context.");
      }
      
      component = ((PyContext*)swigo->ptr)->c;
    }
    
    void messenger_proxy::configure(PyObject* configuration) 
    {
      component->resolve(scpa);    
      lg.dbg("Configure called in c++ wrapper");
    }
    
    void messenger_proxy::install(PyObject*) 
    {
      lg.dbg("Install called in c++ wrapper");
    }
    
  } // namespace applications
} // namespace vigil
