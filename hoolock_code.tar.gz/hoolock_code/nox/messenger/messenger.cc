#include "messenger.hh"
#include "component.hh"
#include "messenger-event.hh"
#include "buffer.hh"
#include "async_io.hh"
#include <errno.h>
#include "errno_exception.hh"
#include <xercesc/dom/DOM.hpp>
#include "vlog.hh"

namespace vigil
{
  using namespace vigil::container;    

  static Vlog_module lg("messenger");
  static const std::string app_name("messenger");
  
  void messenger::configure(const Configuration* config)
  {
    register_event(Msg_event::static_get_name());
    register_event(Sim_handover_event::static_get_name());
    register_event(Hoolock_msg_event::static_get_name());
  }
  
  void messenger::install() 
  {
    new messenger_server(this, portNo);
  }
  
  messenger_server::messenger_server(messenger* messenger, uint16_t portNo)
  {
    msger = messenger;
    server_sock.set_reuseaddr();
    int error = server_sock.bind(htonl(INADDR_ANY), ntohs(portNo));
    if (error)
      throw errno_exception(error, "bind");
    
    error = server_sock.listen(MESSENGER_MAX_CONNECTION);
    if (error)
      throw errno_exception(error, "listen"); 
    
    lg.dbg("messenger TCP interface bound to port %d", portNo);
      start(boost::bind(&messenger_server::run, this));
  }
  
  messenger_server::~messenger_server()
  {
    int error = server_sock.close();
    if (error)
      throw errno_exception(error, "close"); 
  }
  
  void messenger_server::run()
  {
    int error;
    while (true)
    {
      server_sock.accept_wait();
      co_block();
      std::auto_ptr<Tcp_socket> new_socket(server_sock.accept(error, false));
      new messenger_connection(msger, new_socket);
    }
    if (!error)
      lg.err("messenger TCP accept: %d",error);
  }
  
  void messenger::getInstance(const container::Context* ctxt, 
			      vigil::messenger*& scpa) 
  {
    scpa = dynamic_cast<messenger*>
      (ctxt->get_by_interface(container::Interface_description
			      (typeid(messenger).name())));
  }
    
  
  messenger_connection::messenger_connection(messenger* messenger, 
					     std::auto_ptr<Tcp_socket> 
					     new_socket): sock(new_socket)
  { 
    msger = messenger;
    start(boost::bind(&messenger_connection::run, this));
  }
    
  void messenger_connection::run()
  {
    Array_buffer buf(MESSENGER_BUFFER_SIZE);
    uint8_t* dataPointer;
    ssize_t dataSize;
    char internalrecvbuf[MESSENGER_MAX_MSG_SIZE];
    char* endpointer = &internalrecvbuf[0];
    VLOG_DBG(lg,"Socket connection accepted");
    
    running = true;
    while (running)
    {
      //Read message.
      sock->read_wait();
      co_block();
      dataSize = sock->read(buf, false);
      dataPointer = buf.data();
      
      //Copy message into buffer.
      while (dataSize > 0)
      {
	memcpy(endpointer,dataPointer,1);
	
	//Found end of message
	if (*endpointer==';')
	{
	  *endpointer='\0';
	  process(internalrecvbuf);
	  
	  endpointer = &internalrecvbuf[0];
	  dataPointer++;
	  dataSize--;
	}
	else
	{
	  endpointer++;
	  dataPointer++;
	  dataSize--;
	}
      }
    }
    
    int error = sock->close();
    if (error)
      lg.err("messenger TCP connection close: %d", error);
    lg.dbg("socket closed");
  }
  
  void messenger_connection::process(const char* msg)
  {
    if (strcmp(msg, "disconnect_messenger") == 0)
    {
      running = false;
      lg.dbg("Received disconnect message");
    }
    else if (strncmp(msg, "ping",4) == 0)
      msger->post(new Ping_msg_event(sock.get()));
    else if (strncmp(msg, "handover",8) == 0)
      msger->post(new Sim_handover_event(msg));
    else if (strncmp(msg, "chandover",9) == 0)
      msger->post(new Clt_handover_event(msg));
    else if (strncmp(msg, "hoolock",7) == 0)
      msger->post(new Hoolock_msg_event(msg, sock.get()));
    else
      msger->post(new Msg_event(msg, sock.get()));
  }
} // namespace vigil

namespace noxsup
{
  REGISTER_COMPONENT(vigil::container::
		     Simple_component_factory<vigil::messenger>, 
		     vigil::messenger);
}
