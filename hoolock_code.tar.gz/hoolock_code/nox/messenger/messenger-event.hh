#ifndef MESSENGER_EVENT_HH__
#define MESSENGER_EVENT_HH__

#include "event.hh"
#include "netinet++/datapathid.hh"
#include "netinet++/ethernetaddr.hh"
#include "tcp-socket.hh"
#include <boost/bind.hpp>

namespace vigil
{
  /** \brief Message structure for handover message for client.
   *
   * Copyright (C) 2008 Stanford University
   * @author ykk
   * @date October 2008
   * @see Clt_handover_event
   */
  struct Clt_handover_msg
  {
    /** Message identifier.
     */
    char msg_id[9];
    /** MAC address of host.
     */
    char hostMac[12];
    /** Separator.
     */
    char separator1;
    /** Indicate if using SSID
     */
    char usingESSID;
    /** Separator.
     */
    char separator2;
    /** SSID or AP MAC
     */
    char ssidOrAP[20];
  };

  /** \brief Message structure for handover message from simulator.
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.
   * @author ykk
   * @date August 2008
   * @see Sim_handover_event
   */
  struct Sim_handover_msg
  {
    /** Message identifier.
     */
    char msg_id[8];
    /** MAC address of host.
     */
    char hostMac[12];
    /** Separator.
     */
    char separator1;
    /** Datapath id of current switch.
     */
    char srcDP[12];
    /** Separator.
     */
    char separator2;
    /** Datapath id of next switch.
     */
    char dstDP[12];
  };

  /** \brief Handover message from client.
   *
   * Copyright (C) 2008 Stanford University
   * @author ykk
   * @date October 2008
   * @see messenger
   */
  struct Clt_handover_event : public Event
  {
    /** Constructor.
     * @param hostMac mac address of mobile
     * @param ssid_ SSID
     */
    Clt_handover_event(ethernetaddr hostMac, char* ssid_);

    /** Constructor.
     * @param hostMac mac address of mobile
     * @param apMac_ mac of access point
     */
    Clt_handover_event(ethernetaddr hostMac, ethernetaddr apMac_);

    /** Constructor.
     * @param msg message received
     * @see Clt_handover_msg
     */
    Clt_handover_event(const char* msg);
    
    /** Destructor.
     * Deallocate memory for message.
     */
    ~Clt_handover_event()
    { ; }

    /** Empty constructor.
     * For use within python.
     */
    Clt_handover_event() : Event(static_get_name())
    { }

    /** Static name required in NOX.
     */
    static const Event_name static_get_name()
    {
      return "Clt_handover_event";
    }

    /** Host mac.
     */
    ethernetaddr mac;
    /** Indicate if using ESSID or AP mac.
     */
    bool usingESSID;
    /** AP mac.
     */
    ethernetaddr apMac;
    /** String to hold ESSID.
     */
    const char* ssid;
  };

  /** \brief Handover message from simulator.
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.
   * @author ykk
   * @date August 2008
   * @see messenger
   */
  struct Sim_handover_event : public Event
  {
    /** Constructor.
     * @param hostMac mac address of mobile
     * @param srcDP source datapath id
     * @param dstDP destination datapath id
     */
    Sim_handover_event(ethernetaddr hostMac, datapathid srcDP, datapathid dstDP);

    /** Constructor.
     * @param msg message received
     * @see Sim_handover_msg
     */
    Sim_handover_event(const char* msg);

    /** Destructor.
     * Deallocate memory for message.
     */
    ~Sim_handover_event()
    { ; }

    /** Empty constructor.
     * For use within python.
     */
    Sim_handover_event() : Event(static_get_name()) 
    { }

    /** Static name required in NOX.
     */
    static const Event_name static_get_name() 
    {
      return "Sim_handover_event";
    }

    /** Host mac.
     */
    ethernetaddr mac;
    /** Source datapath id.
     */
    datapathid sourceDP;
   /** Destination datapath id.
     */
    datapathid destinationDP;
  };

  /** Ping Message.
   *
   * Copyright (C) Stanford University, 2008.
   * @author ykk
   * @data October 2008
   */
  struct Ping_msg_event : public Event
  {
    /** Constructor.
     * @param socket socket message is received with
     */
    Ping_msg_event(Tcp_socket* socket);

    /** Destructor.
     */
    ~Ping_msg_event()
    { ; }

    /** Empty constructor.
     * For use within python.
     */
    Ping_msg_event() : Event(static_get_name()) 
    { }

    /** Static name required in NOX.
     */
    static const Event_name static_get_name() 
    {
      return "Ping_msg_event";
    }
  };

  /** \brief Structure holding message from messenger.
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.<BR>
   * Copyright (C) Stanford University, 2008.
   * @author ykk
   * @date October 2008
   * @see messenger
   */
  struct Msg_event : public Event
  {
    /** Constructor.
     * Allocate memory for message.
     * @param message message
     * @param socket socket message is received with
     */
    Msg_event(const char* message, Tcp_socket* socket);

    /** Destructor.
     */
    ~Msg_event()
    { ; }

    /** Empty constructor.
     * For use within python.
     */
    Msg_event() : Event(static_get_name()) 
    { }

    /** Static name required in NOX.
     */
    static const Event_name static_get_name() 
    {
      return "Msg_event";
    }

    /** String to hold message.
     */
    const char* msg;
    /** Reference to TCP socket.
     */
    Tcp_socket* sock;
  };

  enum hoolock_cmd {MAKE_REQ, MAKE_ACK, BREAK_REQ, BREAK_ACK};

  struct Hoolock_msg
  {
    /* Message identifier.*/
    char msg_id[7];

    /* MAC address of host. */
    char hostMac[12];
    
    /* Separator. */
    char separator1;

    /* Hoolock command */
    hoolock_cmd cmd;
  };

  struct Hoolock_msg_event : public Event
  {
    /** Constructor.
     * Allocate memory for message.
     * @param message message
     * @param socket socket message is received with
     */
    Hoolock_msg_event(const char* message, Tcp_socket* socket);

    /** Destructor.
     */
    ~Hoolock_msg_event()
    { ; }

    /** Empty constructor.
     * For use within python.
     */
    Hoolock_msg_event() : Event(static_get_name()) 
    { }

    /** Static name required in NOX.
     */
    static const Event_name static_get_name() 
    {
      return "Hoolock_msg_event";
    }

    const char* msg;
    ethernetaddr mac;
    Tcp_socket* sock;
    hoolock_cmd cmd;
  };

}

#endif
