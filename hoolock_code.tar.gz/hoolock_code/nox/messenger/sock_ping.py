#!/usr/bin/python2.5
""" Program to test TCP socket.

./sock_test.py <IP address> <port number>

Created by ykk
Copyright (C) 2008 Stanford University
"""
import noxmsg
import sys

sock = noxmsg.NOXChannel(sys.argv[1],int(sys.argv[2]))
sock.send("ping")
print sock.receive(4)
