#include "messenger-event.hh"
#include "component.hh"
#include "vlog.hh"

namespace vigil
{
  using namespace vigil;
  static Vlog_module lg("messenger-event");

  Sim_handover_event::Sim_handover_event(ethernetaddr hostMac, 
					 datapathid srcDP, datapathid dstDP):
    Event(static_get_name())
  {
    mac = hostMac;
    sourceDP = srcDP;
    destinationDP = dstDP;
  }
  
  Sim_handover_event::Sim_handover_event(const char* msg):
    Event(static_get_name())
  {
    //Process handover message
    Sim_handover_msg* hMsg = (Sim_handover_msg*) msg;
    hMsg->separator1='\0';
    hMsg->separator2='\0';
    mac = ethernetaddr(strtoull(hMsg->hostMac, NULL, 16));
    sourceDP = datapathid::from_host(strtoull(hMsg->srcDP, NULL, 16));
    destinationDP = datapathid::from_host(strtoull(hMsg->dstDP, NULL, 16));
    VLOG_DBG(lg, "Handover of mac:%"PRIx64" from dp:%"PRIx64" to dp:%"PRIx64"",
	     mac.hb_long(), sourceDP.as_host(),destinationDP.as_host());
  }

  Clt_handover_event::Clt_handover_event(const char* msg):
    Event(static_get_name())
  {
    //Process handover message from client
    Clt_handover_msg* hMsg = (Clt_handover_msg*) msg;
    hMsg->separator1='\0';
    hMsg->separator2='\0';
    mac = ethernetaddr(strtoull(hMsg->hostMac, NULL, 16));
    usingESSID = (hMsg->usingESSID == '1');
    if (usingESSID)
      ssid = hMsg->ssidOrAP;
    else
      apMac = ethernetaddr(strtoull(hMsg->ssidOrAP, NULL, 16));

    if (usingESSID)
      VLOG_DBG(lg, "Handover of mac:%"PRIx64" to ESSID:%s ",
	       mac.hb_long(), ssid);
    else
      VLOG_DBG(lg, "Handover of mac:%"PRIx64" to AP:%"PRIx64"",
	       mac.hb_long(), apMac.hb_long());
  }

  Clt_handover_event::Clt_handover_event(ethernetaddr hostMac, ethernetaddr apMac_):
    Event(static_get_name()), usingESSID(false)
  {
    mac = hostMac;
    apMac = apMac_;
  }

  Clt_handover_event::Clt_handover_event(ethernetaddr hostMac, char* ssid_):
    Event(static_get_name()), usingESSID(false)
  {
    mac = hostMac;
    ssid = ssid_;
  }


  Ping_msg_event::Ping_msg_event(Tcp_socket* socket):
    Event(static_get_name())
  {
    VLOG_WARN(lg,"Received ping");
    char msg[5]="echo";
    Nonowning_buffer buf(msg,4);
    socket->write(buf, 0);
  }

  Msg_event::Msg_event(const char* message, Tcp_socket* socket):
    Event(static_get_name()), sock(socket)
  {
    msg = message;
    lg.dbg("Received msg:%s",msg);
  }

  Hoolock_msg_event::Hoolock_msg_event(const char* message, Tcp_socket *socket):
	  Event(static_get_name()), sock(socket)
  {
    msg = message;
    Hoolock_msg* hMsg = (Hoolock_msg*) msg;
    hMsg->separator1='\0';
    mac = ethernetaddr(strtoull(hMsg->hostMac, NULL, 16));
    cmd = hMsg->cmd;
  }
}
