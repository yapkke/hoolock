#!/usr/bin/python2.5
""" Program to test TCP socket.

./sock_test.py <IP address> <port number> <message 1> <message 2> ...

Created by ykk
Copyright (C) 2008 DoCoMo USA Labs, Inc.
"""
import noxmsg
import sys

sock = noxmsg.NOXChannel(sys.argv[1],int(sys.argv[2]))
for i in range(3,len(sys.argv)):
    print (i-2)
    sock.send(sys.argv[i])


       
