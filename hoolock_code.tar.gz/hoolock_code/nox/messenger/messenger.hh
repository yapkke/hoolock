#ifndef MESSENGER_HH__
#define MESSENGER_HH__

#define MESSENGER_BUFFER_SIZE 128
#define MESSENGER_MAX_MSG_SIZE 1024
#define MESSENGER_MAX_CONNECTION 1
#define MESSENGER_PORT 1304

#include "component.hh"
#include "tcp-socket.hh"
#include "threads/cooperative.hh"
#include <boost/bind.hpp>

namespace vigil
{
  using namespace vigil::container;    
  
  /** \brief Class to interact with external programs.
   * Messaging can be tested using python script messenger::sock_test and messenger::sock_ping. 
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.<BR>
   * Copyright (C) Stanford University, 2008.
   * @author ykk
   * @date October 2008
   * @see messenger_server
   * @see sock_test.py
   * @see sock_ping.py
   */
  class messenger : public Component 
  {
  public:
    /** Constructor.
     * Start server socket.
     * @param c context as required by Component
     * @param node Xercesc DOMNode
     */
    messenger(const Context* c, const xercesc::DOMNode* node): Component(c)
    { };

    /** Destructor.
     * Close server socket.
     */
    virtual ~messenger() 
    { };
    
    /** Configure component
     * Register events..
     * @param config configuration
     * @see Sim_msg_event
     * @see Sim_handover_event
     */
    void configure(const Configuration* config);

    /** Start component.
     * Create messenger_server and starts server thread.
     */
    void install();

    /** Get instance of messenger (for python)
     * @param ctxt context
     * @param scpa reference to return instance with
     */
    static void getInstance(const container::Context* ctxt, 
			    vigil::messenger*& scpa);

    /** Server port number (in host order).
     */
    const static uint16_t portNo=MESSENGER_PORT;

  private:
  }; 


  /** \brief Class to accept connections from the messenger.
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.<BR>
   * Copyright (C) Stanford University, 2008.
   * @author ykk
   * @date October 2008
   * @see messenger_connection
   */
  class messenger_server: Co_thread
  {
  public:
    /** Constructor.
     * Open server socket for messages from messenger.
     * @param messenger reference to messenger
     * @param portNo port number to connect to
     */
    messenger_server(messenger* messenger, uint16_t portNo);

    /** Destructor.
     */
    ~messenger_server();

    /** Main function to run socket server as a thread.
     */
    void run();

  private:
    /** TCP server socket accepting connection.
     */
    Tcp_socket server_sock;
    /** Reference to messenger.
     */
    messenger* msger;
  };

  /** \brief Class to handle a connection from the messenger.
   * Parse the message received and push it to NOX.
   *
   * Copyright (C) DoCoMo Communications Lab, USA, 2008.  All rights reserved.<BR>
   * Copyright (C) Stanford University, 2008.
   * @author ykk
   * @date October 2008
   */
  class messenger_connection: Co_thread
  {
  public:
    /** Constructor.
     * Starts thread that handles messages from new socket accepted.
     * @param messenger reference to messenger
     * @param new_socket new socket accepted.
     */
    messenger_connection(messenger* messenger, 
			 std::auto_ptr<Tcp_socket> new_socket);
    /** Destructor.
     */
    ~messenger_connection()
    { ; }
    /** Thread that listens to socket for packets.
     * Packets are expected to end with semicolon, since
     * a buffer is maintained to support the received bytes.
     * Messages are then parsed using the semicolons as markers.
     * Also sends each message for processing.
     * Closes socket once terminated via message.
     * @see process(const char* msg)
     */
    void run();
    /** Function to do default processing of messages received.
     * <UL>
     * <LI>disconnect_messenger; => close listening socket</LI>
     * <LI>handover => handover message</LI>
     * <LI>chandover => client handover message</LI>
     * </UL>
     * @param msg message received
     */
    void process(const char* msg);

  private:
    /** Reference to accepted socket.
     */
    std::auto_ptr<Tcp_socket> sock;
    /** Reference to messenger.
     */
    messenger* msger;
    /** Indicate if thread should continue to run.
     */
    bool running;
  };
} // namespace vigil

#endif 
