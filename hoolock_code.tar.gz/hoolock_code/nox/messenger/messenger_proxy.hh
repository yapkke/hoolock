#ifndef MESSENGER_PROXY_HH__
#define MESSENGER_PROXY_HH__

#include <Python.h>
#include "messenger.hh"
#include "messenger-event.hh"
#include "pyrt/pyglue.hh"

namespace vigil
{
  namespace applications
  {
    /** \brief Class to proxy command between C/C++ and Python for vigil::messenger.
     * 
     * @author ykk
     * @date October 2008
     */
    class messenger_proxy
    {
    public:
      /** Get a pointer to the runtime context so we can resolve 
       * messenger at configure time.
       * @param ctxt context
       */
      messenger_proxy(PyObject* ctxt);
      /** Configure component.
       * Get a handle to the messenger container on the C++ side.
       * Component saved in \ref component
       * @param ctxt context
       */
      void configure(PyObject* ctxt);
      /** Start component in wrapper.
       */
      void install(PyObject*);
      
      // --
      // Proxy public interface methods here!!
      // --
      
    protected:   
      /** messenger component.
       */
      messenger* scpa;
      /** Component container.
       */
      container::Component* component;
    }; 
    
  } // namespace applications
} // namespace vigil

#endif 
